print("Olá, mundo!")
print("Este é o meu primeiro passo com Python e propósito.")